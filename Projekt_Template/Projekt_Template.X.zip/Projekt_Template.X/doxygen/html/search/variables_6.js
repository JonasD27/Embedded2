var searchData=
[
  ['status_0',['status',['../struct_i2_c__struct.html#a1a7ee3550f0aea98fb7854e339e0e4fe',1,'I2C_struct']]],
  ['status_5flicht_1',['status_licht',['../_i2_c_8h.html#a9b4d29ba3bf357b320400e1f01a35610',1,'I2C.h']]],
  ['status_5ftemperatur_2',['status_temperatur',['../_i2_c_8h.html#a11becdc58f1b623b42ad75744dfa6461',1,'I2C.h']]]
];
