var searchData=
[
  ['status_0',['status',['../struct_i2_c__struct.html#a2ba904bc19e627c2369875f49d7daa47',1,'I2C_struct']]]
];
