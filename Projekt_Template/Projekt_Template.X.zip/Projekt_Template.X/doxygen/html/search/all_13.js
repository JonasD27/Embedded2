var searchData=
[
  ['write_0',['write',['../struct_buffer.html#a60e9c75aa693ad12f404344cffc12505',1,'Buffer']]]
];
