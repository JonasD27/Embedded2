var searchData=
[
  ['law_0',['law',['../legal__disclaimer_8txt.html#ab5ba8c53597736795c34cd364fbab675',1,'legal_disclaimer.txt']]],
  ['licensors_1',['licensors',['../legal__disclaimer_8txt.html#abc09d74ec7a7e01ec931c8262e6f59ad',1,'legal_disclaimer.txt']]]
];
