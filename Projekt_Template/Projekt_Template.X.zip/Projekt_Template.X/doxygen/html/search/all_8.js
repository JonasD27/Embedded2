var searchData=
[
  ['heartbeat_5fms_0',['HEARTBEAT_MS',['../main_8c.html#a8095cd8bb3de52fffba928ed8ff15065',1,'HEARTBEAT_MS():&#160;main.c'],['../main__less_8c.html#a8095cd8bb3de52fffba928ed8ff15065',1,'HEARTBEAT_MS():&#160;main_less.c']]]
];
