var searchData=
[
  ['configureoscillator_0',['ConfigureOscillator',['../system_8c.html#a9cf05fad20cabd4ca4a12ab9b1c6e7ea',1,'ConfigureOscillator(void):&#160;system.c'],['../system_8h.html#a9cf05fad20cabd4ca4a12ab9b1c6e7ea',1,'ConfigureOscillator(void):&#160;system.c']]]
];
