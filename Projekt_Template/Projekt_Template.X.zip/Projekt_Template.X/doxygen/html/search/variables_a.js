var searchData=
[
  ['menu_0',['menu',['../getting__started_8txt.html#a6633ed991babfbc17167afb69df2b61a',1,'getting_started.txt']]],
  ['merchantability_1',['MERCHANTABILITY',['../legal__disclaimer_8txt.html#a554ae603815ac5d06c3a17e46327edc1',1,'legal_disclaimer.txt']]]
];
