var searchData=
[
  ['latest_5fcpu_5fload_0',['latest_cpu_load',['../main_8c.html#af832cfb864cc3aedc004597d490001f5',1,'main.c']]],
  ['latest_5ftemperatur_1',['latest_temperatur',['../_i2_c_8h.html#adcd199297f9a8146dd65366775e2cf7d',1,'latest_temperatur():&#160;main.c'],['../main_8c.html#adcd199297f9a8146dd65366775e2cf7d',1,'latest_temperatur():&#160;main.c']]]
];
