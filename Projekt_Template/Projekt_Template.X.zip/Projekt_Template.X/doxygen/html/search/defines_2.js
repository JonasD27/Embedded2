var searchData=
[
  ['cursor_5for_5fdisplay_0',['CURSOR_OR_DISPLAY',['../lcd__gpio_8h.html#a15da8436a10120ffbbb20b0bb2d91efa',1,'CURSOR_OR_DISPLAY():&#160;lcd_gpio.h'],['../_p_m_p_8h.html#a15da8436a10120ffbbb20b0bb2d91efa',1,'CURSOR_OR_DISPLAY():&#160;PMP.h']]],
  ['cycles_5fper_5fmikroseconds_1',['CYCLES_PER_MIKROSECONDS',['../system_8c.html#a81b138c5868e50f6f64ef6c020736e2d',1,'system.c']]],
  ['cycles_5fper_5fmilliseconds_2',['CYCLES_PER_MILLISECONDS',['../system_8c.html#a16788948251eb0d3471982f29e589224',1,'system.c']]]
];
