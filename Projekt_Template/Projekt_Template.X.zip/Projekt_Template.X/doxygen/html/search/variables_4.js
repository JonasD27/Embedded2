var searchData=
[
  ['i2c_5ftest_5fstruct_0',['I2C_test_struct',['../_i2_c_8c.html#a290a8009ff32ac27f0687325153ddcba',1,'I2C_test_struct():&#160;I2C.c'],['../_i2_c_8h.html#a290a8009ff32ac27f0687325153ddcba',1,'I2C_test_struct():&#160;I2C.c']]],
  ['id_1',['ID',['../struct_i2_c__struct.html#aa09a27c6b19d320176ceed96b54e9ab3',1,'I2C_struct']]]
];
