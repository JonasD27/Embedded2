var indexSectionsWithContent =
{
  0: "_abcdefghilmnprstuw",
  1: "bi",
  2: "cdilmpstu",
  3: "_cdefgilmpstw",
  4: "acdfilnrsuw",
  5: "is",
  6: "i",
  7: "efp",
  8: "_bcfhilmrst",
  9: "acep"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Datenstrukturen",
  2: "Dateien",
  3: "Funktionen",
  4: "Variablen",
  5: "Typdefinitionen",
  6: "Aufzählungen",
  7: "Aufzählungswerte",
  8: "Makrodefinitionen",
  9: "Seiten"
};

