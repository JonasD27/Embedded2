var searchData=
[
  ['sensor_5ftime_0',['SENSOR_TIME',['../user_8h.html#a29753842428f7af333a76486ce0286e2',1,'user.h']]],
  ['sys_5ffreq_1',['SYS_FREQ',['../system_8h.html#a7d5ce7b79462bbfb630ee53075540b65',1,'system.h']]]
];
