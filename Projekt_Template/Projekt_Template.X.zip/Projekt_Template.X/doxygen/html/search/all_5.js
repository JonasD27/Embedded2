var searchData=
[
  ['error_0',['Error',['../_i2_c_8h.html#ada1e8e589688e2d6626421d8d85d9c53a4dfd42ec49d09d8c6555c218301cc30f',1,'I2C.h']]],
  ['exchangei2c_1',['exchangeI2C',['../_i2_c_8c.html#afebf0d256affa0109e46790328ec5985',1,'exchangeI2C(uint8_t address, uint16_t num_write, uint8_t *writebuf, uint16_t num_read, uint8_t *readbuf, i2c_status_t *status):&#160;I2C.c'],['../_i2_c_8h.html#afebf0d256affa0109e46790328ec5985',1,'exchangeI2C(uint8_t address, uint16_t num_write, uint8_t *writebuf, uint16_t num_read, uint8_t *readbuf, i2c_status_t *status):&#160;I2C.c']]]
];
