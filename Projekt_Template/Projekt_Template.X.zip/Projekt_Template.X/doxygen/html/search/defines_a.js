var searchData=
[
  ['t0_0',['T0',['../user_8h.html#ad41b89d4eb6d63a0def5e5fd2a5ab326',1,'user.h']]],
  ['t1_1',['T1',['../user_8h.html#ac16509a75e3d3fc46b9df1726be486ec',1,'user.h']]],
  ['t2_2',['T2',['../user_8h.html#a259c2993ee45e06a4ea8150451a7a70e',1,'user.h']]],
  ['t3_3',['T3',['../user_8h.html#a5d800c5f04f8638061876b9e32c6c508',1,'user.h']]]
];
