var searchData=
[
  ['code_2dstyle_0',['Code-Style',['../md__c___users__jonas__documents__git_hub__embedded2__projekt__template__projekt__template__x_doku__code__style.html',1,'']]]
];
