var searchData=
[
  ['read_0',['read',['../struct_buffer.html#ad99a3f990d972bf0b87f25fd507eb599',1,'Buffer']]]
];
