var searchData=
[
  ['callback_0',['callback',['../struct_i2_c__struct.html#aec820d3b0250d8d4ddb99a8cafe79b09',1,'I2C_struct']]]
];
