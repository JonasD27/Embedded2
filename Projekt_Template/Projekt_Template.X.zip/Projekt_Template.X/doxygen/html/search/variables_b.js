var searchData=
[
  ['next_0',['Next',['../getting__started_8txt.html#acca8b16f9fe47230b72ad92aca9de3db',1,'getting_started.txt']]]
];
