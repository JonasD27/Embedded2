var searchData=
[
  ['purpose_0',['PURPOSE',['../legal__disclaimer_8txt.html#a2f87a3f3e4f93dd188a7dc56cbe568b9',1,'legal_disclaimer.txt']]]
];
