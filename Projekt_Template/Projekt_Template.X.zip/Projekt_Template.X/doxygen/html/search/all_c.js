var searchData=
[
  ['num_5fread_0',['num_read',['../struct_i2_c__struct.html#ae857bf437b3affb977fd897f7a9f5cd1',1,'I2C_struct']]],
  ['num_5fwrite_1',['num_write',['../struct_i2_c__struct.html#ae9c7d283903af4094018e1975ae70719',1,'I2C_struct']]]
];
