var searchData=
[
  ['exchangei2c_0',['exchangeI2C',['../_i2_c_8c.html#ab38b9329f69bcb0a02c3b1fc456337d2',1,'exchangeI2C(uint8_t address, uint16_t num_write, uint8_t *writebuf, uint16_t num_read, uint8_t *readbuf, i2c_status_t *status, I2C_Callback_t callback, int16_t ID):&#160;I2C.c'],['../_i2_c_8h.html#ab38b9329f69bcb0a02c3b1fc456337d2',1,'exchangeI2C(uint8_t address, uint16_t num_write, uint8_t *writebuf, uint16_t num_read, uint8_t *readbuf, i2c_status_t *status, I2C_Callback_t callback, int16_t ID):&#160;I2C.c']]]
];
