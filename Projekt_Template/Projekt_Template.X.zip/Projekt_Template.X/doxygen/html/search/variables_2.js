var searchData=
[
  ['data_0',['data',['../struct_buffer___i2_c___f_s_m.html#a361eb6203b893089adcec25bd18b15b5',1,'Buffer_I2C_FSM::data()'],['../struct_buffer.html#a6fefed24f21d9e08925e7904fa7fe887',1,'Buffer::data()'],['../main__less_8c.html#a1cc545950661d96524585c500b3b68d1',1,'data():&#160;main_less.c']]],
  ['delay_5fanpassung_1',['DELAY_ANPASSUNG',['../main__less_8c.html#a3674e1feb03e742150964aa79b8fe8df',1,'DELAY_ANPASSUNG():&#160;main_less.c'],['../system_8c.html#a3674e1feb03e742150964aa79b8fe8df',1,'DELAY_ANPASSUNG():&#160;system.c'],['../system_8h.html#a3674e1feb03e742150964aa79b8fe8df',1,'DELAY_ANPASSUNG():&#160;main_less.c']]]
];
