var struct_i2_c__struct =
[
    [ "address", "struct_i2_c__struct.html#af3f726014b044194def151079f1f2d89", null ],
    [ "num_read", "struct_i2_c__struct.html#ae857bf437b3affb977fd897f7a9f5cd1", null ],
    [ "num_write", "struct_i2_c__struct.html#ae9c7d283903af4094018e1975ae70719", null ],
    [ "readbuf", "struct_i2_c__struct.html#a857014f4e286cf04cddf4447eb45430b", null ],
    [ "status", "struct_i2_c__struct.html#a1a7ee3550f0aea98fb7854e339e0e4fe", null ],
    [ "writebuf", "struct_i2_c__struct.html#a9d9d3335bc1243d5f7bb4bc7795238a9", null ]
];