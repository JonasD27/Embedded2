var user_8h =
[
    [ "BUFFER_FAIL", "user_8h.html#a130a78573f3f044449912e5a564bab60", null ],
    [ "BUFFER_SIZE", "user_8h.html#a6b20d41d6252e9871430c242cb1a56e7", null ],
    [ "BUFFER_SUCCESS", "user_8h.html#a6861758eca7b115454b77ded9d29eebd", null ],
    [ "LED0", "user_8h.html#ae8d5b4e7e2d9d21caaa4744d385d7cc7", null ],
    [ "LED1", "user_8h.html#a8aa85ae9867fabf70ec72cd3bf6fb6b9", null ],
    [ "LED2", "user_8h.html#ad09fe5bf321b9a2de26bd5e5b9af6424", null ],
    [ "LED3", "user_8h.html#a4b7ff8e253a7412f83deba3a447028a8", null ],
    [ "SENSOR_TIME", "user_8h.html#a29753842428f7af333a76486ce0286e2", null ],
    [ "T0", "user_8h.html#ad41b89d4eb6d63a0def5e5fd2a5ab326", null ],
    [ "T1", "user_8h.html#ac16509a75e3d3fc46b9df1726be486ec", null ],
    [ "T2", "user_8h.html#a259c2993ee45e06a4ea8150451a7a70e", null ],
    [ "T3", "user_8h.html#a5d800c5f04f8638061876b9e32c6c508", null ],
    [ "InitApp", "user_8h.html#addc0a16fa099430e2337628a38764b67", null ]
];