var struct_buffer___i2_c___f_s_m =
[
    [ "data", "struct_buffer___i2_c___f_s_m.html#a361eb6203b893089adcec25bd18b15b5", null ],
    [ "read", "struct_buffer___i2_c___f_s_m.html#ad99a3f990d972bf0b87f25fd507eb599", null ],
    [ "write", "struct_buffer___i2_c___f_s_m.html#a60e9c75aa693ad12f404344cffc12505", null ]
];