var system_8c =
[
    [ "ConfigureOscillator", "system_8c.html#a9cf05fad20cabd4ca4a12ab9b1c6e7ea", null ],
    [ "delay_ms", "system_8c.html#a9d9be562445321043224885018bc7da3", null ],
    [ "init_ms_t4", "system_8c.html#ab0bb063f480450e226799ab30cc6a3ed", null ],
    [ "init_timer1", "system_8c.html#af460918a62cf83ab0848c41f0ae852ea", null ]
];