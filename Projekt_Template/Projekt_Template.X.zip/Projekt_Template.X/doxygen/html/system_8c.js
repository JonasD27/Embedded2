var system_8c =
[
    [ "CYCLES_PER_MIKROSECONDS", "system_8c.html#a81b138c5868e50f6f64ef6c020736e2d", null ],
    [ "CYCLES_PER_MILLISECONDS", "system_8c.html#a16788948251eb0d3471982f29e589224", null ],
    [ "ConfigureOscillator", "system_8c.html#a9cf05fad20cabd4ca4a12ab9b1c6e7ea", null ],
    [ "delay_ms", "system_8c.html#a9d9be562445321043224885018bc7da3", null ],
    [ "delay_us", "system_8c.html#a4e5aeb021ad85c23675337730148d5c4", null ],
    [ "init_ms_t4", "system_8c.html#ab0bb063f480450e226799ab30cc6a3ed", null ],
    [ "init_t2_t3", "system_8c.html#a85f94a0dfff81bccb50e5cf5528c46c7", null ],
    [ "init_timer1", "system_8c.html#af460918a62cf83ab0848c41f0ae852ea", null ],
    [ "DELAY_ANPASSUNG", "system_8c.html#a3674e1feb03e742150964aa79b8fe8df", null ]
];