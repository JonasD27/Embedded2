var main_8c =
[
    [ "HEARTBEAT_MS", "main_8c.html#a8095cd8bb3de52fffba928ed8ff15065", null ],
    [ "MAIN", "main_8c.html#a34b04bd23b07b485921a728ad0805ac4", null ],
    [ "display_temp_load", "main_8c.html#add65c2bbc4a328fc893abeded917bc66", null ],
    [ "display_UART_RX", "main_8c.html#a394ee1d3ce36d2ac7f571753a6a99a9d", null ],
    [ "get_Light", "main_8c.html#a93551653b71e7a2a6bcc02a359a35d6a", null ],
    [ "get_Temperatur", "main_8c.html#a1b7d65e89a8c4488df180a296015b1b6", null ],
    [ "main", "main_8c.html#aec570f4ab450e8224be63b7dcfa62b35", null ],
    [ "measureProcesstime", "main_8c.html#a6188587bd216339104622b4a766d00b2", null ],
    [ "print_sensor_values", "main_8c.html#a8a04c6bbc751721e41e25af6d8f10915", null ],
    [ "send_lcd_status", "main_8c.html#a37d537911df5a0124f1a43b0070cd138", null ],
    [ "latest_cpu_load", "main_8c.html#af832cfb864cc3aedc004597d490001f5", null ],
    [ "latest_temperatur", "main_8c.html#adcd199297f9a8146dd65366775e2cf7d", null ],
    [ "read_data_buffer_light", "main_8c.html#a812b49b4aafdf99e12c75ed8005948a1", null ],
    [ "read_data_buffer_temp", "main_8c.html#aef8997c71403e269e83a8e8478ccf73c", null ],
    [ "received_UART", "main_8c.html#a00c6bb525f28a5f4d4a47a82479b2790", null ],
    [ "status_licht", "main_8c.html#a9b4d29ba3bf357b320400e1f01a35610", null ],
    [ "status_temperatur", "main_8c.html#a11becdc58f1b623b42ad75744dfa6461", null ],
    [ "UART_RX_count", "main_8c.html#ad0e60ba05c0f067879e9c46e5bce10d6", null ],
    [ "write_data_buffer_light", "main_8c.html#a2d5347585325c234d8c68be50f2eb6a0", null ],
    [ "write_data_buffer_temp", "main_8c.html#adff71d8937a9a0e682b3a195f98be0df", null ]
];