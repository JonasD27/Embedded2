var main_8c =
[
    [ "HEARTBEAT_MS", "main_8c.html#a8095cd8bb3de52fffba928ed8ff15065", null ],
    [ "MAIN", "main_8c.html#a34b04bd23b07b485921a728ad0805ac4", null ],
    [ "main", "main_8c.html#aec570f4ab450e8224be63b7dcfa62b35", null ]
];