var system_8h =
[
    [ "FCY", "system_8h.html#a99d7c812ba23bfdba5d29ec2fddf1e83", null ],
    [ "SYS_FREQ", "system_8h.html#a7d5ce7b79462bbfb630ee53075540b65", null ],
    [ "ConfigureOscillator", "system_8h.html#a9cf05fad20cabd4ca4a12ab9b1c6e7ea", null ],
    [ "delay_ms", "system_8h.html#a9d9be562445321043224885018bc7da3", null ],
    [ "init_ms_t4", "system_8h.html#ab99293b6cbbc43735cbe80ab55287b29", null ],
    [ "init_t2_t3", "system_8h.html#a7f243ab14250b38842452f61ea5ba40c", null ],
    [ "init_timer1", "system_8h.html#a4c8a60bd5612f0a209df26f391461c6c", null ],
    [ "DELAY_ANPASSUNG", "system_8h.html#a3674e1feb03e742150964aa79b8fe8df", null ]
];