var traps_8c =
[
    [ "_AddressError", "traps_8c.html#a7d0e17c4ba9d457c33ee70078744b9c8", null ],
    [ "_DefaultInterrupt", "traps_8c.html#ad66b851d3e30e7398cfce55cd2137629", null ],
    [ "_MathError", "traps_8c.html#a712462e16d3037efc5e9969f62fe6ee2", null ],
    [ "_OscillatorFail", "traps_8c.html#aec63791363b2065eddc5e0517ef6d237", null ],
    [ "_StackError", "traps_8c.html#a6ecef055982dcb7c83228dad7e5cd4de", null ]
];