var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "f", "globals_f.html", null ],
    [ "g", "globals_g.html", null ],
    [ "h", "globals_h.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ],
    [ "w", "globals_w.html", null ]
];