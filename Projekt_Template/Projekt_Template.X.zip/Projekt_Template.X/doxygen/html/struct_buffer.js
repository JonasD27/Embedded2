var struct_buffer =
[
    [ "data", "struct_buffer.html#a6fefed24f21d9e08925e7904fa7fe887", null ],
    [ "read", "struct_buffer.html#ad99a3f990d972bf0b87f25fd507eb599", null ],
    [ "write", "struct_buffer.html#a60e9c75aa693ad12f404344cffc12505", null ]
];