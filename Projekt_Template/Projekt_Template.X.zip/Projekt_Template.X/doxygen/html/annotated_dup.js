var annotated_dup =
[
    [ "Buffer", "struct_buffer.html", "struct_buffer" ],
    [ "Buffer_I2C_FSM", "struct_buffer___i2_c___f_s_m.html", "struct_buffer___i2_c___f_s_m" ],
    [ "I2C_struct", "struct_i2_c__struct.html", "struct_i2_c__struct" ]
];